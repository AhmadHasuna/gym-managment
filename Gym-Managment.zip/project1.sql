﻿/*===============================================================
     name-Ahmad hasone
     מערכת ניהול חדר כושר - Gym Management System

===============================================================*/

CREATE DATABASE Gym_Management_System;
GO

USE Gym_Management_System;
GO

/*---------------------------------------------------------------
  טבלת Users
---------------------------------------------------------------
  מטרה:
    שמירת פרטי לקוחות (מנויים) של חדר הכושר, כולל פרטים אישיים
    כמו שם, גיל, כתובת, אימייל וסיסמה.

  שדות עיקריים:
    - userID (Primary Key)
    - fname, lname, gender, age
    - contact_address, email, password

  קשרים:
    -  userID טבלה זו מקושרת לכל שאר הטבלאות באמצעות 
----------------------------------------------------------------*/

CREATE TABLE Users (
    userID INT PRIMARY KEY,
    fname VARCHAR(255) NOT NULL,
    lname VARCHAR(255) NOT NULL,
    gender VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    contact_address VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255)
);


/*---------------------------------------------------------------
  טבלת Plans
---------------------------------------------------------------
  מטרה:
    מייצגת את תוכנית המנוי של כל משתמש חודשי, שנתי, פעיל/מוקפא

  שדות עיקריים:
    - planID (Primary Key)
    - userID (Foreign Key)
    - status, start_date

  קשרים:
    - Users כל תוכנית שייכת למשתמש אחד מטבלת 
----------------------------------------------------------------*/

CREATE TABLE Plans (
    planID INT PRIMARY KEY,
    userID INT REFERENCES Users(userID),
    status VARCHAR(255),
    start_date DATE
);

/*---------------------------------------------------------------
  טבלת Payments
---------------------------------------------------------------
  מטרה:
    תיעוד כל תשלום שבוצע ע"י המשתמש למנוי, תוספות וכו'.

  שדות עיקריים:
    - paymentID (Primary Key)
    - userID (Foreign Key)
    - date, amount

  קשרים:
    -Users כל תשלום שייך למשתמש אחד מטבלת   
----------------------------------------------------------------*/
CREATE TABLE Payments (
    paymentID INT PRIMARY KEY,
    userID INT REFERENCES Users(userID),
    date DATE,
    amount INT
);

/*---------------------------------------------------------------
  טבלת Transactions
---------------------------------------------------------------
  מטרה:
    שמירת עסקאות שונות שבוצעו (שדרוגים, קנסות, ביטולים).

  שדות עיקריים:
    - transactionID (Primary Key)
    - userID (Foreign Key)
    - transaction_name, amount, date

  קשרים:
    - Users כל עסקה משויכת למשתמש מטבלת   
    -Reports משמשת מקור לדוחות בטבלת    
----------------------------------------------------------------*/
CREATE TABLE Transactions (
    transactionID INT PRIMARY KEY,
    transaction_name VARCHAR(255),
    userID INT REFERENCES Users(userID),
    amount INT,
    date DATE
);

/*---------------------------------------------------------------
  טבלת Reports
---------------------------------------------------------------
  מטרה:
    דו"חות כספיים/ניהוליים הכוללים מידע כולל ללקוח.

  שדות עיקריים:
    - reportID (Primary Key)
    - userID (Foreign Key)
    - transactionID (Foreign Key)

  קשרים:
    - כל דו"ח מקושר למשתמש ולעסקה.
----------------------------------------------------------------*/
CREATE TABLE Reports (
    reportID INT PRIMARY KEY,
    userID INT REFERENCES Users(userID),
    transactionID INT REFERENCES Transactions(transactionID)
);

/*---------------------------------------------------------------
  טבלת Coaches
---------------------------------------------------------------
  מטרה:
    אחסון פרטים של מאמנים :שם, אימייל, שכר וכו

  שדות עיקריים:
    - coachID (Primary Key)
    - name, salary, email, password

  קשרים:
    - coachID דרך TrainingSchedule מקושרת לטבלת 
----------------------------------------------------------------*/
CREATE TABLE Coaches (
    coachID INT PRIMARY KEY NOT NULL,
    name VARCHAR(255) NOT NULL,
    salary INT,
    email VARCHAR(255),
    password INT
);


/*---------------------------------------------------------------
  טבלת TrainingSchedule
---------------------------------------------------------------
  מטרה:
    יומן אימונים: מי מתאמן עם איזה מאמן, מתי, ואיזו פעילות.

  שדות עיקריים:
    - scheduleID (Primary Key)
    - userID (Foreign Key)
    - coachID (Foreign Key)
    - session, activity, date, timestart, timeend

  קשרים:
    - מקושרת ל-Users (userID) ול-Coaches (coachID).
----------------------------------------------------------------*/

CREATE TABLE TrainingSchedule (
    scheduleID INT PRIMARY KEY,
    userID INT REFERENCES Users(userID),
    coachID INT REFERENCES Coaches(coachID),
    session VARCHAR(250),
    activity VARCHAR(250),
    date DATE,
    timestart TIME,
    timeend TIME
);

----*** insert data to users table
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (1, 'Amy', 'Ramos', 'Male', 54,
            'Fake Street 1', 'lroberts@gmail.com', 'pass001');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (2, 'Michael', 'Johnson', 'Male', 45,
            'Fake Street 2', 'collinshunter@gmail.com', 'pass002'); 

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (3, 'Lauren', 'Olsen', 'Male', 46,
            'Fake Street 3', 'daymichael@ortega.net', 'pass003');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (4, 'William', 'Garza', 'Female', 18,
            'Fake Street 4', 'michael80@yahoo.com', 'pass004');
   
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (5, 'Laurie', 'Davis', 'Male', 50,
            'Fake Street 5', 'rhondaduncan@hotmail.com', 'pass005');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (6, 'Lauren', 'Holt', 'Female', 56,
            'Fake Street 6', 'joseph39@hotmail.com', 'pass006');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (7, 'Tracy', 'Johnson', 'Male', 48,
            'Fake Street 7', 'patriciagreen@rogers.com', 'pass007');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (8, 'Philip', 'Yates', 'Male', 38,
            'Fake Street 8', 'amandaknight@shelton.org', 'pass008');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (9, 'Ivan', 'Reed', 'Male', 25,
            'Fake Street 9', 'julieperez@stokes.org', 'pass009');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (10, 'Louis', 'Richardson', 'Female', 31,
            'Fake Street 10', 'courtneymelton@dyer.com', 'pass010');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (11, 'Amy', 'Rodriguez', 'Female', 44,
            'Fake Street 11', 'william43@yahoo.com', 'pass011'); 

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (12, 'Holly', 'Walsh', 'Female', 58,
            'Fake Street 12', 'henry55@hotmail.com', 'pass012');
   
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (13, 'Christopher', 'Coleman', 'Male', 59,
            'Fake Street 13', 'anthonyperry@hotmail.com', 'pass013');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (14, 'Kathleen', 'Ortiz', 'Female', 31,
            'Fake Street 14', 'jacobwang@gmail.com', 'pass014');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (15, 'Sydney', 'Lopez', 'Male', 56,
            'Fake Street 15', 'jamesmoore@gmail.com', 'pass015');
   
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (16, 'Greg', 'Stewart', 'Female', 44,
            'Fake Street 16', 'gene45@yahoo.com', 'pass016');

INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (17, 'Jacqueline', 'Griffin', 'Male', 59,
            'Fake Street 17', 'buckmark@hotmail.com', 'pass017');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (18, 'Scott', 'Mitchell', 'Female', 56,
            'Fake Street 18', 'aaroncarter@gutierrez-brooks.biz', 'pass018');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (19, 'Peter', 'Esparza', 'Female', 26,
            'Fake Street 19', 'icraig@gmail.com', 'pass019');
    
INSERT INTO Users (userID, fname, lname, gender, age, contact_address, email, password)
    VALUES (20, 'Megan', 'Phillips', 'Female', 32,
            'Fake Street 20', 'taylorbrian@stephenson.com', 'pass020');
   
-----***insert data to coaches table
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (1, 'Robert Allen', 9815, 'kathrynrodriguez@bell.com', 9686);
    
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (2, 'Melissa Montgomery', 5411, 'gregorybowen@gmail.com', 5896);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (3, 'Megan Macias', 9435, 'gflowers@hotmail.com', 7692);
    
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (4, 'Jamie Thompson', 7241, 'davidpeters@hotmail.com', 1351);
    

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (5, 'Jennifer Hudson', 6139, 'carrie51@hotmail.com', 6596);
   
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (6, 'Courtney Moore', 8278, 'taylorgray@williams.biz', 1696);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (7, 'Nicholas Simmons', 7086, 'tapiatracy@gmail.com', 9094);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (8, 'Brittany Bridges', 9394, 'stephanie84@gmail.com', 9885);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (9, 'Tara Campbell', 6475, 'catherinecastillo@hotmail.com', 8954);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (10, 'Jeff Mccormick', 8807, 'evan71@macias-snyder.info', 8359);
   
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (11, 'Terry Price', 5102, 'torresmichael@gillespie-johnson.com', 9228);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (12, 'Jody Pollard', 7241, 'vwilliams@harrison.com', 7582);
   
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (13, 'Meredith Martinez', 8456, 'sheila79@butler.com', 1761);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (14, 'Ashley Diaz', 6567, 'parkernicholas@hotmail.com', 7209);
    
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (15, 'Emily Ramos', 9858, 'rodney31@yahoo.com', 7612);
   
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (16, 'Shirley Cortez', 6872, 'andrew34@hotmail.com', 9734);
    
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (17, 'Meagan Morris', 7294, 'jessica63@huber.net', 3762);
    
INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (18, 'Regina Graves', 5283, 'jjones@gmail.com', 3944);

INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (19, 'Joseph Smith', 9704, 'meganmaldonado@simon-brown.com', 3929);
    
 INSERT INTO Coaches (coachID, name, salary, email, password)
    VALUES (20, 'Timothy Gonzales', 7617, 'kendra06@yahoo.com', 8837);
    
----**** insert data to TrainingSchedule table
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
VALUES (1, 17, 5, 'Session 1', 'Yoga',
            '2024-12-30', '09:42:26', '20:39:10');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (2, 1, 20, 'Session 2', 'Weightlifting',
            '2025-03-19', '17:14:32', '14:26:43');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (3, 6, 9, 'Session 3', 'Yoga',
            '2024-06-11', '02:25:04', '08:01:34');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (4, 8, 3, 'Session 4', 'Weightlifting',
            '2025-03-20', '03:38:25', '15:19:56');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (5, 15, 18, 'Session 5', 'Weightlifting',
            '2024-10-14', '16:25:40', '02:26:14');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (6, 1, 19, 'Session 6', 'Weightlifting',
            '2024-04-27', '22:27:28', '22:33:36');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (7, 7, 8, 'Session 7', 'HIIT',
            '2024-09-14', '00:44:30', '01:55:34');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (8, 16, 2, 'Session 8', 'Yoga',
            '2024-08-19', '04:57:54', '14:29:12');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (9, 10, 8, 'Session 9', 'Zumba',
            '2025-01-14', '19:10:33', '16:32:34');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (10, 5, 17, 'Session 10', 'Yoga',
            '2025-04-15', '19:14:10', '10:00:52');
   
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (11, 19, 16, 'Session 11', 'Weightlifting',
            '2024-11-08', '14:12:08', '17:22:49');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (12, 4, 15, 'Session 12', 'Zumba',
            '2024-09-14', '13:30:27', '19:23:21');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (13, 3, 7, 'Session 13', 'Pilates',
            '2024-11-25', '03:24:00', '01:21:43');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (14, 7, 8, 'Session 14', 'HIIT',
            '2024-05-04', '12:46:56', '14:42:25');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (15, 15, 4, 'Session 15', 'Pilates',
            '2025-01-04', '14:39:55', '17:06:33');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (16, 1, 15, 'Session 16', 'Weightlifting',
            '2024-11-05', '20:59:34', '04:38:12');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (17, 14, 15, 'Session 17', 'Zumba',
            '2025-03-04', '17:11:56', '12:46:27');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (18, 2, 10, 'Session 18', 'Zumba',
            '2025-03-16', '18:21:19', '09:54:14');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (19, 10, 15, 'Session 19', 'Pilates',
            '2025-01-04', '14:35:48', '08:13:18');
    
INSERT INTO TrainingSchedule (scheduleID, userID, coachID, session, activity, date, timestart, timeend)
    VALUES (20, 13, 12, 'Session 20', 'HIIT',
            '2024-07-03', '15:15:24', '05:05:54');
    
----***insert data to plans table
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (1, 12, 'Inactive', '2024-12-07');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (2, 1, 'Inactive', '2025-03-31');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (3, 17, 'Inactive', '2025-04-14');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (4, 7, 'Inactive', '2024-11-09');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (5, 6, 'Inactive', '2024-05-03');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (6, 3, 'Inactive', '2025-01-08');
    
 INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (7, 9, 'Inactive', '2024-12-04');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (8, 18, 'Active', '2024-11-23'); 

INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (9, 14, 'Active', '2024-11-19');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (10, 10, 'Inactive', '2024-05-30');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (11, 8, 'Inactive', '2024-09-21'); 

INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (12, 18, 'Active', '2024-12-28');

INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (13, 19, 'Inactive', '2024-10-19');
   
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (14, 1, 'Inactive', '2024-05-19');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (15, 19, 'Active', '2025-03-22');
   
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (16, 12, 'Inactive', '2025-03-12');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (17, 9, 'Active', '2024-09-25');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (18, 8, 'Inactive', '2024-10-29');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (19, 11, 'Active', '2024-04-17');
    
INSERT INTO Plans (planID, userID, status, start_date)
    VALUES (20, 15, 'Active', '2024-05-22');
    

----**** insert data to payments table
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (1, 8, '2024-11-21', 339);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (2, 15, '2024-09-21', 439); 

INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (3, 7, '2025-01-26', 557);
   
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (4, 11, '2024-11-18', 298);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (5, 11, '2024-06-30', 397);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (6, 3, '2025-02-22', 485);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (7, 9, '2024-06-26', 269);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (8, 14, '2024-12-25', 520);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (9, 17, '2024-10-14', 525);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (10, 10, '2025-03-24', 494);

INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (11, 6, '2024-11-09', 167);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (12, 4, '2024-10-25', 546);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (13, 4, '2024-10-13', 236);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (14, 16, '2024-05-31', 593);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (15, 12, '2024-10-08', 279);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (16, 12, '2024-08-01', 436);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (17, 6, '2024-04-30', 316);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (18, 20, '2024-06-12', 414);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (19, 8, '2024-09-25', 346);
    
INSERT INTO Payments (paymentID, userID, date, amount)
    VALUES (20, 14, '2024-09-04', 240); 


-----***** insert data to Transactions table
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (1, 'Penalty', 16, 1115, '2024-09-10');

INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (2, 'Purchase', 10, 747, '2024-08-11');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (3, 'Penalty', 3, 1070, '2025-01-23');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (4, 'Penalty', 13, 956, '2024-04-18');
   
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (5, 'Purchase', 12, 1028, '2024-08-09');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (6, 'Penalty', 18, 488, '2024-09-05');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (7, 'Renewal', 14, 227, '2025-03-28');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (8, 'Penalty', 1, 592, '2025-01-20');
  
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (9, 'Renewal', 3, 339, '2024-04-19');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (10, 'Purchase', 15, 485, '2025-04-06');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (11, 'Purchase', 11, 468, '2024-10-22');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (12, 'Upgrade', 19, 289, '2024-07-05');

INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (13, 'Purchase', 19, 248, '2024-11-03');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (14, 'Purchase', 11, 924, '2024-11-15');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (15, 'Penalty', 1, 745, '2025-02-28');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (16, 'Renewal', 15, 522, '2024-08-15');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (17, 'Renewal', 3, 428, '2025-01-26');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (18, 'Penalty', 14, 571, '2025-02-02');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (19, 'Renewal', 20, 809, '2024-10-08');
    
INSERT INTO Transactions (transactionID, transaction_name, userID, amount, date)
    VALUES (20, 'Penalty', 16, 404, '2024-04-18');
    
------**** insert data to Reports table 
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (1, 19, 1);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (2, 20, 2);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (3, 12, 3);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (4, 14, 4);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (5, 8, 5);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (6, 9, 6);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (7, 2, 7);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (8, 5, 8);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (9, 14, 9);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (10, 13, 10);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (11, 8, 11);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (12, 18, 12);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (13, 18, 13);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (14, 1, 14);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (15, 4, 15);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (16, 14, 16);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (17, 7, 17);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (18, 8, 18);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (19, 12, 19);
    
INSERT INTO Reports (reportID, userID, transactionID)
    VALUES (20, 8, 20);
    

